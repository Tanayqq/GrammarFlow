document.addEventListener('DOMContentLoaded', () => {
    const langSelect = document.getElementById('langSelect');
    const styleSelect = document.getElementById('styleSelect');
    const toneSelect = document.getElementById('toneSelect');
    const humanizeToggle = document.getElementById('humanizeToggle');
    const saveBtn = document.getElementById('saveBtn');
    const saveStatus = document.getElementById('saveStatus');

    // Load saved settings
    chrome.storage.sync.get({
        language: 'English',
        style: 'Casual',
        tone: 'Friendly',
        humanize: true
    }, (prefs) => {
        langSelect.value = prefs.language;
        styleSelect.value = prefs.style;
        toneSelect.value = prefs.tone;
        humanizeToggle.checked = prefs.humanize;
    });

    // Save settings
    saveBtn.addEventListener('click', () => {
        const prefs = {
            language: langSelect.value,
            style: styleSelect.value,
            tone: toneSelect.value,
            humanize: humanizeToggle.checked
        };

        chrome.storage.sync.set(prefs, () => {
            saveStatus.textContent = "Saved!";
            saveStatus.style.opacity = "1";
            
            setTimeout(() => {
                saveStatus.style.opacity = "0";
            }, 2000);
        });
    });
});
