const API_BASE = "https://grammarflow-brain.onrender.com/api/v1";

// Create context menu on install
chrome.runtime.onInstalled.addListener(() => {
    console.log("[GrammarFlow] Extension installed, creating context menu.");
    chrome.contextMenus.create({
        id: "improve-grammarflow",
        title: "Improve with GrammarFlow",
        contexts: ["selection", "editable"]
    });
});

// Handle context menu click
chrome.contextMenus.onClicked.addListener((info, tab) => {
    console.log("[GrammarFlow] Context menu clicked:", info);
    if (info.menuItemId === "improve-grammarflow") {
        console.log(`[GrammarFlow] Sending TRIGGER_IMPROVE to tab ${tab.id}`);
        // Send message to content script to show UI and initiate rewrite
        chrome.tabs.sendMessage(tab.id, {
            action: "TRIGGER_IMPROVE",
            text: info.selectionText || "" // If it's an editable but no text selected, content.js will extract it
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("[GrammarFlow] Message failed:", chrome.runtime.lastError.message);
            } else {
                console.log("[GrammarFlow] Message delivered successfully.");
            }
        });
    }
});

// Handle API requests from content scripts (to bypass CORS)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "API_CALL") {
        handleApiCall(request.endpoint, request.payload)
            .then(apiResponse => sendResponse(apiResponse))
            .catch(error => sendResponse({ success: false, error: error.message }));
        
        return true; // Indicates async response
    }
});

async function handleApiCall(endpoint, payload) {
    const url = `${API_BASE}${endpoint}`;
    
    // Fetch global preferences to merge with payload
    const prefs = await chrome.storage.sync.get({
        language: 'English',
        style: 'Casual',
        tone: 'Friendly',
        humanize: true
    });

    const body = {
        ...payload,
        language: prefs.language,
        style: prefs.style,
        tone: prefs.tone,
        humanize: prefs.humanize
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
    }

    return await response.json();
}
