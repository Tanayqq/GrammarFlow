let activeOverlay = null;
let activeTarget = null;
let activeSelectionRange = null;

// Listen for Context Menu trigger
console.log("[GrammarFlow] Content script loaded successfully.");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("[GrammarFlow] Received message:", request.action);
    if (request.action === "TRIGGER_IMPROVE") {
        sendResponse({ received: true });
        handleImproveRequest();
    }
});

function handleImproveRequest() {
    activeTarget = document.activeElement;
    
    // Get text and selection range
    let textToImprove = "";
    activeSelectionRange = null;

    if (activeTarget.tagName === "TEXTAREA" || activeTarget.tagName === "INPUT") {
        textToImprove = activeTarget.value.substring(activeTarget.selectionStart, activeTarget.selectionEnd);
        if (!textToImprove) {
            textToImprove = activeTarget.value; // Fallback to full text
        }
    } else if (activeTarget.isContentEditable || document.designMode === "on") {
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
            activeSelectionRange = selection.getRangeAt(0);
            textToImprove = selection.toString();
        }
        if (!textToImprove) {
            textToImprove = activeTarget.innerText; // Fallback
            // Select all if no selection was made
            const range = document.createRange();
            range.selectNodeContents(activeTarget);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            activeSelectionRange = range;
        }
    } else {
        // Just standard text selection on the page
        textToImprove = window.getSelection().toString();
    }

    textToImprove = textToImprove.trim();
    console.log("[GrammarFlow] Extracted text to improve:", textToImprove);

    if (textToImprove.length < 5) {
        console.log("[GrammarFlow] Text too short, aborting.");
        alert("GrammarFlow: Please select at least a few words to improve.");
        return;
    }

    showOverlay();
    fetchSuggestions(textToImprove);
}

function showOverlay() {
    if (activeOverlay) activeOverlay.remove();

    activeOverlay = document.createElement('div');
    activeOverlay.id = 'gf-inline-overlay';
    
    activeOverlay.innerHTML = `
        <div id="gf-inline-header">
            <div class="gf-logo">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                GrammarFlow
            </div>
            <div class="gf-close">&times;</div>
        </div>
        <div id="gf-inline-content">
            <div class="gf-loading-state">
                <div class="gf-spinner"></div>
                Analyzing text...
            </div>
        </div>
        <div id="gf-inline-footer" style="display: none;">
            <button class="gf-btn" id="gf-apply-btn" disabled>Apply</button>
        </div>
    `;

    document.body.appendChild(activeOverlay);

    // Position overlay near selection
    positionOverlay();

    // Event Listeners
    activeOverlay.querySelector('.gf-close').addEventListener('click', () => {
        activeOverlay.remove();
        activeOverlay = null;
    });
}

function positionOverlay() {
    const selection = window.getSelection();
    let rect;
    
    if (selection.rangeCount > 0 && !selection.isCollapsed) {
        rect = selection.getRangeAt(0).getBoundingClientRect();
    } else if (activeTarget) {
        rect = activeTarget.getBoundingClientRect();
    }

    if (rect) {
        const top = rect.bottom + window.scrollY + 10;
        const left = rect.left + window.scrollX;
        
        // Prevent going off-screen
        const maxLeft = window.innerWidth - 390;
        
        activeOverlay.style.top = `${top}px`;
        activeOverlay.style.left = `${Math.min(left, maxLeft)}px`;
    } else {
        activeOverlay.style.top = '20px';
        activeOverlay.style.right = '20px';
    }
}

function fetchSuggestions(text) {
    chrome.runtime.sendMessage({
        action: "API_CALL",
        endpoint: "/rewrite",
        payload: { text: text }
    }, (response) => {
        const contentDiv = activeOverlay.querySelector('#gf-inline-content');
        
        if (!response || !response.success) {
            contentDiv.innerHTML = `<div style="color: #ef4444;">Failed to connect to GrammarFlow API.</div>`;
            return;
        }

        const data = response.data;
        if (!data || data.length === 0) {
            contentDiv.innerHTML = `<div style="color: #a1a1aa;">Text looks good! No suggestions needed.</div>`;
            return;
        }

        // /rewrite returns an array of strings. Map them to objects for the UI.
        const formattedData = data.map((str, i) => ({
            suggestion: str,
            category: i === 0 ? "Best Rewrite" : "Alternative",
            reason: "Complete sentence rewrite"
        }));

        renderSuggestions(formattedData);
    });
}

let selectedSuggestionText = "";

function renderSuggestions(suggestions) {
    const contentDiv = activeOverlay.querySelector('#gf-inline-content');
    const footerDiv = activeOverlay.querySelector('#gf-inline-footer');
    const applyBtn = activeOverlay.querySelector('#gf-apply-btn');
    
    contentDiv.innerHTML = "";
    footerDiv.style.display = "flex";

    suggestions.forEach((sug, index) => {
        const item = document.createElement('div');
        item.className = 'gf-suggestion-item';
        
        item.innerHTML = `
            ${sug.category ? `<div class="gf-suggestion-category">${sug.category}</div>` : ''}
            <div class="gf-suggestion-text">${sug.suggestion}</div>
            <div class="gf-suggestion-reason">${sug.reason || ''}</div>
        `;

        item.addEventListener('click', () => {
            // Deselect others
            activeOverlay.querySelectorAll('.gf-suggestion-item').forEach(el => {
                el.style.background = 'rgba(255,255,255,0.02)';
                el.style.borderColor = 'rgba(255,255,255,0.05)';
            });
            // Select this
            item.style.background = 'rgba(139, 92, 246, 0.1)';
            item.style.borderColor = '#a78bfa';
            
            selectedSuggestionText = sug.suggestion;
            applyBtn.disabled = false;
        });

        contentDiv.appendChild(item);

        // Auto-select first item
        if (index === 0) {
            item.click();
        }
    });

    applyBtn.onclick = () => applyText(selectedSuggestionText);
}

function applyText(newText) {
    if (!activeTarget) return;

    activeTarget.focus();

    if (activeTarget.tagName === "TEXTAREA" || activeTarget.tagName === "INPUT") {
        const start = activeTarget.selectionStart;
        const end = activeTarget.selectionEnd;
        activeTarget.setRangeText(newText, start, end, 'select');
        
        // Dispatch input event to notify frameworks (React, Vue)
        activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
    } 
    else if (activeTarget.isContentEditable || document.designMode === "on") {
        // Restore selection range if it was lost when interacting with overlay
        if (activeSelectionRange) {
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(activeSelectionRange);
        }
        
        // Use execCommand for rich text editors (Gmail, LinkedIn) - standard approach
        document.execCommand("insertText", false, newText);
    }

    if (activeOverlay) {
        activeOverlay.remove();
        activeOverlay = null;
    }
}
