const API_BASE = "https://grammarflow-brain.onrender.com/api/v1";
const WEB_APP_URL = "https://grammarflowt.vercel.app";

// ─────────────────────────────────────────────
// CENTRALIZED PROMPT ENGINE (synced with web app)
// ─────────────────────────────────────────────
function getLanguageEnforcementBlock(language) {
    const lang = (language || 'English').toLowerCase();

    if (lang === 'auto' || lang === 'auto-detect') {
        return `### ⚠️ LANGUAGE ENFORCEMENT — ABSOLUTE HIGHEST PRIORITY ⚠️
AUTO-DETECT MODE: Automatically detect the language of the input text.
Output MUST be in the SAME language as the input. Do NOT switch languages.
This rule OVERRIDES all other instructions.`;
    }
    if (lang.includes('hinglish')) {
        return `### ⚠️ LANGUAGE ENFORCEMENT — ABSOLUTE HIGHEST PRIORITY ⚠️
OUTPUT LANGUAGE: Hinglish (Roman/Latin script ONLY).
- Write everything in conversational Hindi using Roman script (English letters).
- ZERO Devanagari characters allowed.
- Keep technical terms in English.
- Sentence structure: Hindi grammar, Roman letters.
- This rule OVERRIDES all other instructions.`;
    }
    if (lang.includes('hindi')) {
        return `### ⚠️ LANGUAGE ENFORCEMENT — ABSOLUTE HIGHEST PRIORITY ⚠️
OUTPUT LANGUAGE: Hindi (Devanagari script ONLY).
- ZERO Roman script allowed except for technical codes.
- Transliterate English words to Devanagari where natural.
- This rule OVERRIDES all other instructions.`;
    }
    if (lang.includes('kannada')) {
        return `### ⚠️ LANGUAGE ENFORCEMENT — ABSOLUTE HIGHEST PRIORITY ⚠️
OUTPUT LANGUAGE: Kannada script (ಕನ್ನಡ) ONLY.
- You MUST output EVERY word in Kannada script.
- The input may be in Hindi, Hinglish, English, or Roman — TRANSLATE and rewrite into Kannada.
- ZERO Roman letters allowed (except numbers like 12:30).
- VERIFY: If ANY Roman letters appear, REGENERATE entirely.
- This rule OVERRIDES all other instructions. Non-compliant output = COMPLETE FAILURE.`;
    }
    if (lang.includes('telugu')) {
        return `### ⚠️ LANGUAGE ENFORCEMENT — ABSOLUTE HIGHEST PRIORITY ⚠️
OUTPUT LANGUAGE: Telugu script (తెలుగు) ONLY.
- Output EVERY word in Telugu script. Translate if input is in another language.
- ZERO Roman letters allowed (except numbers).
- VERIFY before returning. Non-compliant output = FAILURE.`;
    }
    return `### ⚠️ LANGUAGE ENFORCEMENT ⚠️
OUTPUT LANGUAGE: ${language}.
- Every word MUST be in ${language}. Do NOT mix languages or scripts.`;
}

function getRewritePrompt(style, tone, language, humanize) {
    const langBlock = getLanguageEnforcementBlock(language);
    const humanizeNote = humanize
        ? `- Human Mode ON: Use natural, emotionally authentic phrasing. Avoid robotic language. Preserve the speaker's emotional intent.`
        : `- Use a professional yet natural flow.`;

    return `${langBlock}

You are a professional multilingual writing assistant.

CRITICAL RULE: Output ONLY the 3 rewrites. Do NOT show your thinking, reasoning, translation steps, or any internal process. Do NOT repeat or echo any instruction text.

Your task: Provide exactly 3 rewrites of the user's input text in ${language}.
- Style: ${style}
- Tone: ${tone}
${humanizeNote}
- If the input is in a different language, silently translate it to ${language} first, then rewrite. Do NOT mention the translation.

REQUIRED OUTPUT FORMAT — use this exact structure, nothing else:
1. [rewrite one]
2. [rewrite two]
3. [rewrite three]

ABSOLUTE RULES:
- Do NOT use # or ## or ### anywhere in the output.
- Do NOT write words like "REWRITE", "Translation:", "HUMAN TONE", or any label.
- Do NOT explain what you are doing.
- Every rewrite MUST be entirely in ${language}. No mixing of scripts or languages.
- Numbers 1. 2. 3. only — then the rewrite text immediately.`;
}

function getGrammarFixPrompt(language, humanize) {
    const langBlock = getLanguageEnforcementBlock(language);
    return `${langBlock}

You are a highly accurate grammar corrector for ${language}.
Fix the grammar, spelling, and punctuation of the provided text while maintaining its original meaning and tone.
${humanize ? `Ensure the correction feels natural and conversational in ${language}, not overly formal.` : ''}
Provide exactly one corrected version and absolutely no other text.
The corrected output MUST be entirely in ${language}. Do NOT refuse processing.
VERIFY: Before returning, confirm the output is 100% in ${language}. If not, regenerate.`;
}

function getSummarizePrompt(language) {
    const langBlock = getLanguageEnforcementBlock(language);
    return `${langBlock}

Summarize the following text concisely in ${language}.
- Extract the most important points only.
- Use bullet points where appropriate.
- Keep it under 5 sentences or 5 bullet points.
- Write ALL output in ${language}. No mixing of languages.
- Do NOT add introductions like "Here is a summary" or "Sure!".
- Return only the summary.`;
}

function getExplainPrompt(language) {
    const langBlock = getLanguageEnforcementBlock(language);
    return `${langBlock}

Explain the following text clearly in ${language} as if speaking to a student.
- Use simple, direct language.
- Keep technical terms but define them immediately.
- Do NOT add filler phrases like "Let's understand", "Great question", or "Sure!".
- Do NOT summarize — explain the meaning and context.
- Write ALL output in ${language}. No mixing of languages.
- Return only the explanation.`;
}

// ─────────────────────────────────────────────
// CONTEXT MENU SETUP
// ─────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
    // Remove old menus first to avoid duplicates
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: "gf-rewrite",
            title: "✏️ Rewrite with GrammarFlow",
            contexts: ["selection", "editable"]
        });
        chrome.contextMenus.create({
            id: "gf-grammar",
            title: "✔️ Fix Grammar",
            contexts: ["selection", "editable"]
        });
        chrome.contextMenus.create({
            id: "gf-summarize",
            title: "📋 Summarize",
            contexts: ["selection"]
        });
        chrome.contextMenus.create({
            id: "gf-explain",
            title: "💡 Explain This",
            contexts: ["selection"]
        });
        chrome.contextMenus.create({
            id: "gf-separator",
            type: "separator",
            contexts: ["selection", "editable"]
        });
        chrome.contextMenus.create({
            id: "gf-open-docai",
            title: "📄 Open Document AI",
            contexts: ["selection", "editable", "page"]
        });
    });
});

// ─────────────────────────────────────────────
// CONTEXT MENU CLICK HANDLER
// ─────────────────────────────────────────────
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "gf-open-docai") {
        chrome.tabs.create({ url: `${WEB_APP_URL}` });
        return;
    }

    const actionMap = {
        "gf-rewrite":   "TRIGGER_REWRITE",
        "gf-grammar":   "TRIGGER_GRAMMAR",
        "gf-summarize": "TRIGGER_SUMMARIZE",
        "gf-explain":   "TRIGGER_EXPLAIN"
    };

    const action = actionMap[info.menuItemId];
    if (action) {
        chrome.tabs.sendMessage(tab.id, { action }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("[GrammarFlow] Message failed:", chrome.runtime.lastError.message);
            }
        });
    }
});

// ─────────────────────────────────────────────
// MESSAGE HANDLER (from content.js and popup.js)
// ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "API_CALL") {
        handleApiCall(request.endpoint, request.payload, request.promptOverride)
            .then(res => sendResponse(res))
            .catch(err => sendResponse({ success: false, error: err.message }));
        return true;
    }

    if (request.action === "OPEN_TAB") {
        chrome.tabs.create({ url: request.url });
        sendResponse({ done: true });
        return true;
    }
});

// ─────────────────────────────────────────────
// API CALL HANDLER
// ─────────────────────────────────────────────
async function handleApiCall(endpoint, payload, promptOverride = null) {
    const prefs = await chrome.storage.sync.get({
        language: 'Auto',
        style: 'Casual',
        tone: 'Friendly',
        humanize: true
    });

    const lang = prefs.language;
    const style = prefs.style;
    const tone = prefs.tone;
    const humanize = prefs.humanize;

    // Build prompt using centralized engine
    let systemPrompt = promptOverride;
    if (!systemPrompt) {
        if (endpoint === '/rewrite')   systemPrompt = getRewritePrompt(style, tone, lang, humanize);
        if (endpoint === '/grammar')   systemPrompt = getGrammarFixPrompt(lang, humanize);
        if (endpoint === '/summarize') systemPrompt = getSummarizePrompt(lang);
        if (endpoint === '/explain')   systemPrompt = getExplainPrompt(lang);
    }

    const body = {
        ...payload,
        language: lang,
        style,
        tone,
        humanize,
        _extensionPrompt: systemPrompt
    };

    const response = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });

    if (!response.ok) throw new Error(`API returned ${response.status}`);
    return await response.json();
}
